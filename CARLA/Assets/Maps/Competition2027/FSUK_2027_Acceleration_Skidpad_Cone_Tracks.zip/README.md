# Formula Student UK 2027 — Acceleration and Skidpad cone-track fixtures

These are deterministic, **importer-ready cone courses** for the current
ASURT CARLA FlatAsphalt simulator and its independent planning-mode tests.
They are **not Unreal .umap assets**, and opening them does not modify CARLA.
They are derived from the user's uploaded `Dynamic_Missions_Details.pdf`
(© 2027 IMechE, Formula Student UK 2027 Rules, pages 116–117 and 119).
The generated drawing/reference path is a simulation test design, **not**
an official organizer-supplied coordinate list or a verified autonomous path.

## Open and import

In **CARLA System Manager → Tools → Cone Track Importer**, click either
**2027 Acceleration** or **2027 Skidpad**. This only loads a local CSV and
draws its 2D preview. You can also choose either generated `*_cones.csv` or
`*_cones.json` using **Choose CSV / JSON**; both contain identical cone
positions and pass the importer's actual `load_cones` parser.

1. Choose **2027 Acceleration** or **2027 Skidpad**. Confirm the blue/yellow
   counts and the first gate; for these files, **Mirror Y is OFF**.
2. Select a large, unobstructed portion of the running **FlatAsphalt** map
   using the GUI's fixed X/Y/Z/yaw fields. Local +X is forward along the
   approach, and +Y is CARLA's right. Ensure the entire cone course fits.
   The importer defaults may not fit a 130 m Acceleration course.
3. Keep **Project onto terrain** selected. Use **Find ground-supported
   placement** if required, then **Preview cones** and inspect all lane
   markers. These operations do not create physical cone actors.
4. When the preview is on drivable ground, use **Spawn physical cones**.
   Its ownership guards prevent overwriting an existing live managed course.
   To change event, use **Remove my cones** only after checking ownership,
   then select the other course and repeat.
5. **Preview car start** before using the separate **POSITION EXISTING FSAI
   CAR AT TRACK START** button. These importer tests use the *first blue/yellow
   gate* as the initial car reference. The competition rules instead measure
   staging from the **foremost point of the vehicle**: adjust **Car start
   offset** by the actual FSAI front-footprint distance before a timing test.
   Neither generated cone file moves the car automatically.
6. In the System Manager select the corresponding PathPlanning module and
   the same **Planning RViz view** to compare its output with the imported
   cones. The SLAM cone mapper must observe the imported physical cones
   before the map-only planners can publish a meaningful course.

Use a separate full course at a time so mapped landmarks from different
tracks are never mixed. A route reference is **not a controller command**.
Do not use the exported reference CSV as accepted Control authority.

## Files

| Event | Import cones | Geometry and timing | Ideal preview |
| --- | --- | --- | --- |
| Acceleration | [CSV](acceleration/acceleration_2027_cones.csv) / [JSON](acceleration/acceleration_2027_cones.json) | [Layout JSON](acceleration/acceleration_2027_layout.json) | [PNG](acceleration/acceleration_2027_preview.png) / [SVG](acceleration/acceleration_2027_preview.svg) |
| Skidpad | [CSV](skidpad/skidpad_2027_cones.csv) / [JSON](skidpad/skidpad_2027_cones.json) | [Layout JSON](skidpad/skidpad_2027_layout.json) | [PNG](skidpad/skidpad_2027_preview.png) / [SVG](skidpad/skidpad_2027_preview.svg) |

Each event also includes a `*_reference_path.csv` with `stage,x,y,z`
for offline geometry inspection. `manifest.json` indexes all outputs.
`generate_dynamic_courses.py` regenerates all coordinates and previews;
it makes no simulator calls. `test_dynamic_courses.py` checks dimensions,
spacing, ring cone counts, importer compatibility, clearance and planner
geometry without interacting with the running ROS or CARLA processes.

## D4 Skidpad

Rules D4.1.1–D4.1.6 and Figure 8 (PDF page 1, rulebook page 116):

- Right/left circle centres: `(15,+9.125)` and `(15,-9.125)` metres
  in local **CARLA** XY. Separation: **18.25 m**.
- Painted inner diameter **15.25 m**, outer diameter **21.25 m**.
  Painted inner/outer radii **7.625 m** and **10.625 m**; middle of the
  driving lane has radius **9.125 m** and its nominal width is **3.0 m**.
- Exactly **16 inner** and **13 outer** cone markers per circle:
  58 ring cones. Two blue/yellow approach gates at X=0 and X=5 and
  three exit gates at X=30/35/40 add ten lane cones: **68 in total**
  (34 blue, 34 yellow).
- The central timing line is X=15 m. The prescribed foremost-point staging
  is 15 m before it at X=0; the exit/stop lane extends to X=40 m, 25 m
  behind that timing line. Rule D4.3.5 calls for **two right-circle laps,
  then two left-circle laps**, followed by an exit in the entry direction.

Figure 8 shows the exterior ring cones **absent through the crossover**.
Uniformly spacing 13 cones around the full outside circumference would block
the opposite loop. The generated outer-ring cones occupy 260 degrees on each
exterior arc, preserving 100-degree clear crossover openings. This is a
documented approximation of the printed pattern because the rules do not
provide exact outer-cone angular coordinates. The generator checked
every reference route sample against every cone; clearance is at least
**1.65 m to the centre of a cone**, and the closest two cone centres are
more than **1.83 m** apart. This is an offline 2D check, not collision
certification for a real vehicle footprint.

For this simulation the cone centres are placed 0.15 m **inside** the painted
inner circle and 0.15 m **outside** the painted outer circle. That offset,
the particular blue/yellow assignments and the gate spacing are explicit
layout choices, not specified in the PDF. The physical painted corridor
remains 3.0 m wide between the stated diameters.

The colors are chosen for the ASURT planner and CARLA importer: blue is left
and yellow right relative to motion. On the CARLA right circle this maps to
blue outer/yellow inner; on the CARLA left circle it is blue inner/yellow
outer. The CARLA bridge converts Y into ROS REP-103, so the corresponding
map-only Skidpad planner uses its original calibrated circle directions.

## D5 Acceleration

Rule D5.1.1 (PDF page 4, rulebook page 119) specifies **75 m** from starting
to finish line, **at least 3 m width**, and cones at **about 5 m** intervals.
This test course has:

- Timed straight X=0 to X=75, chosen lane width **3.5 m** (exceeds minimum).
- Boundary stations every **5 m**, inclusive at X=0/5/…/75.
- Additional approach cone pair at X=-5 and marked driverless stopping lane
  X=80/85/…/125 (D5.3.4: stop within 50 m after finish).
- **54 cones** (27 blue and 27 yellow). Cone centres are 0.15 m outside
  the 3.5 m nominal line edges, resulting in **3.8 m** centre separation.

Per D5.3.2, the **foremost point** of the FSAI must be 0.30 m behind the
X=0 start line. The imported first gate lies at X=-5 to preserve the
approach course; do not mistake its auto-placement pose for certified
staging. Use the car preview, physical body footprint, and offset field.
The marked 50 m stopping lane is an inferred testing layout: the rules
mandate the distance and marked lane but do not specify exact cone positions
or interval within the exit lane.

## Rebuild and verify (offline)

From the ASURT repository root:

```bash
python3 Simulation/CARLA/Maps/Competition2027/generate_dynamic_courses.py
python3 -m unittest discover -s Simulation/CARLA/Maps/Competition2027 -p 'test_*.py' -v
```

The tests call the same actual `load_cones`, `track_start` and
`suggested_invert_y` functions as the importer, then feed a simulated
CARLA-to-ROS Y-reflected cone map into the **Acceleration** and **Skidpad**
planning geometries. They do not assume that a sensor has yet detected
or mapped the imported physical cones. Actual Map RViz path quality depends
on ZED detection, odometry and SLAM association, and still requires live
moving-vehicle validation. These fixtures establish correct source layouts,
not proven competition runs.
